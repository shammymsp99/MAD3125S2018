package com.example.macstudent.login;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class NewParkingActivity extends AppCompatActivity implements  View.OnClickListener , AdapterView.OnItemSelectedListener {

    Spinner spnCarCompany, spnLot, SpnSpot,spnPayment;
    TextView txtAmount, txtDateTime;
    EditText edtCarPlate;
    Button btnAddParking;
    RadioButton rdoOne,rdoTwo,rdoThre,rdoFour;

    int parkingRate [] = {10,20,30,40,50};
String lot[] = {"a","b","c","d","e","f","g","h","i","j","k"};
String Spot[] = {"1","2","3","4","5","6","7","8","9","10"};
String payment [] = {"debit","credit","master card","devit card"};
String carCompany[] = {"BMW","Audi","Jaguar","Mercedes","Lexus"};
int logos[] = {R.drawable.img_bmw,R.drawable.img_audi,R.drawable.img_jaguar,R.drawable.img_mercedes,R.drawable.img_lexus};

String selectedLot,selectedpayment, selectedSpot, selectedCompany;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_parking);

        spnCarCompany = findViewById(R.id.spnCarCompany);
        CarCompanyAdapter carCompanyAdapter = new CarCompanyAdapter(getApplicationContext(),logos,carCompany);
        spnCarCompany.setAdapter(carCompanyAdapter);
        spnCarCompany.setOnItemSelectedListener(this);

        spnLot= findViewById(R.id.spnlot);
        ArrayAdapter lotAdapter = new ArrayAdapter( this, android.R.layout.simple_spinner_item, lot );
        lotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnLot.setAdapter(lotAdapter);
        spnLot.setOnItemSelectedListener(this);

        SpnSpot = findViewById(R.id.spnSpot);

        SpnSpot= findViewById(R.id.spnSpot);
        ArrayAdapter spotAdapter = new ArrayAdapter( this, android.R.layout.simple_spinner_item, Spot );
        spotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnLot.setAdapter(spotAdapter);
        spnLot.setOnItemSelectedListener(this);


        spnPayment=findViewById(R.id.spnPayment);
        spnPayment= findViewById(R.id.spnPayment);
        ArrayAdapter paymentAdapter = new ArrayAdapter( this, android.R.layout.simple_spinner_item, payment );
        paymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnPayment.setAdapter(paymentAdapter);
        spnPayment.setOnItemSelectedListener(this);

        txtAmount = findViewById(R.id.txtAmount);
        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(Calendar.getInstance().getTime().toString());

        edtCarPlate = findViewById(R.id.edtCarPlate);
        btnAddParking = findViewById(R.id.addparking);

        rdoOne = findViewById(R.id.rdoOne);
        rdoOne.setOnClickListener(this);

        rdoTwo = findViewById(R.id.rdoTwo);
        rdoTwo.setOnClickListener(this);

        rdoThre = findViewById(R.id.rdoThree);
        rdoThre.setOnClickListener(this);

        rdoFour = findViewById(R.id.rdoFour);
        rdoFour.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {

        if(rdoOne.isChecked()) {
            txtAmount.setText("$" + parkingRate[0]);
        }else  if(rdoTwo.isChecked()) {
            txtAmount.setText("$" + parkingRate[0]);
        }
            else  if(rdoThre.isChecked()) {
                txtAmount.setText("$" + parkingRate[0]);
            }
            else  if(rdoFour.isChecked()) {
            txtAmount.setText("$" + parkingRate[0]);
            }

            if (btnAddParking.getId() == view.getId()){
                SharedPreferences sp = getSharedPreferences("com.example.macstudent.login.shared", Context.MODE_PRIVATE);
                SharedPreferences.Editor edit = sp.edit();

                edit.putString("CarPlate",edtCarPlate.getText().toString());
                edit.putString("CarCompany",selectedCompany);
                edit.putString("Lot",selectedLot);
                edit.putString("Spot",selectedSpot);
                edit.putString("Payment",selectedpayment);
                edit.putString("DateTime",txtDateTime.getText().toString());
                edit.putInt("Amount", Integer.parseInt(txtAmount.getText().toString().substring(1)));

                edit.commit();

                 startActivity(new Intent(getApplicationContext(),RecieptActivity.class));

            }

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView,View view, int position , long l){
        if (adapterView.getId()==spnLot.getId()){
            selectedLot = lot [position];

        }
        else  if (adapterView.getId()==SpnSpot.getId()){
            selectedSpot = Spot [position];

        }
        else  if (adapterView.getId()==spnPayment.getId()){
            selectedpayment = payment [position];

        }else if(adapterView.getId() == spnCarCompany.getId()){
            selectedCompany = carCompany[position];
        }





    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
