package com.example.macstudent.mycart;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;


public class BillReciept extends AppCompatActivity {

    TextView txtDateTime, txtProducts, txtManuName, txtQuantity, txtTotal;

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), HomeScreen.class));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bill_reciept);

        SharedPreferences sp = getSharedPreferences("com.example.macstudent.mycart.shared", Context.MODE_PRIVATE);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(sp.getString("DateTime","Data Missing"));

        txtProducts = findViewById(R.id.txtProducts);
        txtProducts.setText(sp.getString("Products","Data Missing"));

        txtManuName = findViewById(R.id. txtManuName);
        txtManuName.setText("Lot " + sp.getString("Manufacturer Name ", "Data Missing"));

        txtQuantity = findViewById(R.id.txtQuantity);
        txtQuantity.setText("Spot " + sp.getString("Quantity", "Data Missing"));

        txtTotal = findViewById(R.id.txtTotal);
        txtTotal.setText(String.valueOf(sp.getInt("Total Amount", 0)));
    }
}
