package com.example.macstudent.mycart;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class ProductsAdapter extends BaseAdapter {

    int[] logos;
    String[] ManuName;
    Context context;
    LayoutInflater inflater;

    ProductsAdapter(Context context, String[] ManuName){
        this.ManuName = ManuName;
        this.context = context;
        inflater = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return ManuName.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = inflater.inflate(R.layout.product_spinner_item,null);

        ImageView imgLogo =(ImageView) convertView.findViewById(R.id.imgLogo);
        TextView txtCompany = convertView.findViewById(R.id.txtProducts);

        imgLogo.setImageResource(this.logos[position]);
        txtCompany.setText(this.ManuName[position]);

        return convertView;
    }
}
