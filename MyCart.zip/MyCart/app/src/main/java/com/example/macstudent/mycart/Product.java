package com.example.macstudent.mycart;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class Product extends AppCompatActivity {

    Spinner spnProducts, spnManuName, spnQuantity, spnPayment;
    TextView txtTotal, txtDateTime;
    EditText edtPrice;
    Button btnAddProducts;
    RadioButton rdoOne, rdoTwo, rdoThree, rdoFour;

    String manuname[] = {"A","B","C","D","E","F"};
    String quantity[] = {"1","2","3","4","5"};
    String payment[] = {"Debit Card", "Credit Card", "Master Card", "American Express", "Cash"};
    String Product[] = {"Milk", "Choclates", "Chips", "Biscuits","Fruits"};
    int logos[] = {R.drawable.milk,R.drawable.choco,R.drawable.chips,R.drawable.biscuit,R.drawable.cart};
    String selectedManuName, selectedQuantity, selectedPayment, selectedProducts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product);

        spnProducts = findViewById(R.id.spnProducts);
        ProductsAdapter productsAdapter = new ProductsAdapter(getApplicationContext(), logos, Product);
        spnProducts.setAdapter(productsAdapter);
        spnProducts.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);

        spnManuName = findViewById(R.id.spnManuName);
        ArrayAdapter manuAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, manuname);
        manuAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnManuName.setAdapter(manuAdapter);
        spnManuName.setOnItemSelectedListener(this);


        spnQuantity = findViewById(R.id.txtQuantity);
        ArrayAdapter quantityAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, quantity);
        quantityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnQuantity.setAdapter(quantityAdapter);
        spnQuantity.setOnItemSelectedListener(this);

        spnPayment = findViewById(R.id.spnTotal);
        ArrayAdapter paymentAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, payment);
        paymentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnPayment.setAdapter(paymentAdapter);
        spnPayment.setOnItemSelectedListener(this);

        txtTotal = findViewById(R.id.txtTotal);
        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(Calendar.getInstance().getTime().toString());

        edtPrice = findViewById(R.id.edtPrice);

        btnAddProducts = findViewById(R.id.btnAddProducts);
        btnAddProducts.setOnClickListener(this);

        rdoOne = findViewById(R.id.rdoOne);
        rdoOne.setOnClickListener(this);

        rdoTwo = findViewById(R.id.rdoTwo);
        rdoTwo.setOnClickListener((View.OnClickListener) this);

        rdoThree = findViewById(R.id.rdoThree);
        rdoThree.setOnClickListener(this);

        rdoFour = findViewById(R.id.rdoFour);
        rdoFour.setOnClickListener(this);


    }
}
