package com.example.macstudent.mycart;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class ViewOrder extends BaseAdapter {

    LayoutInflater inflater;
    Context context;
    String[] Prices = {"32.33","23.24","5.01"};
    String[] total = {"10","20","50"};
    String[] ManuName = {"A", "B", "C"};
    String[] Quantity = {"1", "41", "23"};
    String[] dateTime = {"12-12-2018 12:12:12 PM", "12-12-2018 13:12:12 PM",
            "12-12-2018 18:10:10 PM"};

    ViewOrder(Context context){
        this.context = context;
        inflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return Prices.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.list_report_item, null);

        TextView txtDateTime = view.findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime[position]);

        TextView txtProducts = view.findViewById(R.id.txtProducts);
        txtProducts.setText(Product[position]);

        TextView txtTotal = view.findViewById(R.id.txtTotal);
        txtTotal.setText("$" + total[position]);

        TextView txtManuName = view.findViewById(R.id.txtManuName);
        txtManuName.setText("Manufacturer Name : " + ManuName[position]);

        TextView txtSpot = view.findViewById(R.id.txtQuantity);
        txtSpot.setText("Quantity : " + Quantity[position]);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "item " + position + " selected", Toast.LENGTH_LONG).show();
            }
        });
        return view;
    }
}
