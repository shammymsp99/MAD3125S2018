package com.example.macstudent.mycart;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBName = "GroceryCartDB";
    public static final String TBName_Products = "Products";

    public DBHelper(Context context) {
        super(context, DBName, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        try{
            String CREATE_TABLE = "CREATE TABLE " + TBName_Products +
                    "(PName varchar(50), PCategory varchar(20)," +
                    "ManuName varchar(50) PRIMARY KEY, Price float(20)," +
                    "quantity int(20))";

            Log.v("DBHelper",CREATE_TABLE);

            sqLiteDatabase.execSQL(CREATE_TABLE);

        }catch(Exception e){
            Log.e("DBHelper",e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int olderVersion, int newerVersion) {
        try{
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TBName_Products);

            onCreate(sqLiteDatabase);

        }catch(Exception e){
            Log.e("DBHelper", e.getMessage());
        }
    }
}
